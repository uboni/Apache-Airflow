from airflow.models import Variable

random_num = Variable.get('random_num')