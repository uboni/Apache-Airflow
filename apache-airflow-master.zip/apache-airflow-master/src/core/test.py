def hello_method(**kwargs):
    task_instance = kwargs['ti']
    dict_x ={1: 'x', 2: 'y'}
    print(dict_x)
